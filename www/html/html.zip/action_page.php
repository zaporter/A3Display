<html>
<body>

Passphrase: <?php echo $_POST["passphrase"]; ?><br>
Code: <?php echo $_POST["code"]; ?>

</body>
</html>
